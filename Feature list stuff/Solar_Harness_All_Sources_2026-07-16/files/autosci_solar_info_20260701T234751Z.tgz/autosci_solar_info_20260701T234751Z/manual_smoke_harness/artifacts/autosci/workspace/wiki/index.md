# Solar AutoSci Wiki

Human-facing research memory projected from Solar-managed evidence.

Last projected run: `info-smoke-research`

## Demo Entry Points

| Question | Status | Page | What to inspect |
| --- | --- | --- | --- |
| what ran | ok | [lifecycle_summary](outputs/lifecycle_summary.md) | Lifecycle status, node/gate results, and blocked nodes. |
| what was produced | pending | [report](outputs/report.md) | Report artifact, evidence ids, and publication limitations. |
| what is blocked | pending | [review](outputs/review.md) | Review availability, findings, and blocking reasons. |
| what evidence exists | pending | [ideas](outputs/ideas.md) | Candidate/evaluation evidence and promotion boundaries. |
| what remains incomplete | pending | [experiment](outputs/experiment.md) | Approval/runtime audit, collection, and remote proof status. |

## Papers

- [paper-demo-paper](papers/paper-demo-paper.md)

## Foundations

- N/A

## Concepts

- N/A

## Methods

- N/A

## People

- N/A

## Topics

- N/A

## Ideas

- N/A

## Experiments

- N/A

## Outputs

- [PIPELINE_REPORT](outputs/PIPELINE_REPORT.md)
- [lifecycle_summary](outputs/lifecycle_summary.md)
- [pipeline-progress](outputs/pipeline-progress.md)


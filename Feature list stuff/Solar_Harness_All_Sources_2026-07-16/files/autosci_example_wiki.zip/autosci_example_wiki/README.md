# Illustrative AutoSci Wiki

This package is a hand-built example that follows AutoSci's current wiki directory,
entity schema, and Markdown templates. It is based on the uploaded SKILLGEN paper.

It is **not** the literal output of an AutoSci execution, and the proposed idea and
planned experiment have not been run. The purpose is to show what `wiki/` looks like
after paper ingestion, ideation, and experiment design.

---
title: "Reduce held-out skill regressions with cross-validated verification gating"
slug: reduce-held-out-regressions-with-cross-validated-gating
status: in_progress
origin: "Limitation in the SKILLGEN paper: candidates accepted on the construction-time verification subset can still regress on the final held-out set."
origin_gaps: ["[[paired-skill-verification]]", "[[agent-skill-synthesis]]"]
tags: [verification, regression-control, agent-skills, uncertainty]
target_venue: ""
priority: 4
pilot_result: ""
failure_reason: ""
linked_experiments: ["[[cross-validated-verification-gate-main]]"]
date_proposed: 2026-06-19
date_resolved: ""
---

## Motivation

[[skillgen-verified-inference-time-agent-skill-synthesis]] shows that a fixed
verification gate removes many harmful candidate skills, but accepted candidates can
still overgeneralize on unseen instances.

## Hypothesis

A cross-validated gate that estimates uncertainty in net gain will reduce final
held-out regressions while preserving most of the repairs achieved by the original
fixed-subset gate.

## Approach sketch

Partition the construction-time verification pool into several folds. For every
candidate skill, estimate repairs, regressions, and net gain across folds. Accept a
candidate only when its lower confidence bound is positive and its regression rate
does not exceed a configured guard threshold. Compare this against the original
single-split SKILLGEN gate under the same candidate skills and rollout budget.

## Novelty argument

The paper performs paired verification and baseline-success guard checks, but the
proposed extension explicitly estimates variation across verification folds and uses
that uncertainty in the deployment decision.

## Target venue

To be decided after pilot results.

## Risks

- Additional evaluation cost
- Small folds may produce unstable confidence estimates
- A conservative gate may reject useful candidates
- Reusing the same candidate sequence may still couple selection and evaluation

## Pilot results

Not run in this illustrative wiki.

## Lessons learned

Not yet available.

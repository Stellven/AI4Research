# Context Brief

## Research focus

The wiki currently covers automatic synthesis of reusable inference-time agent skills.

## Core paper

[[skillgen-verified-inference-time-agent-skill-synthesis]] introduces [[skillgen]], a
three-stage system combining baseline elicitation, [[contrastive-behavioral-induction]],
and [[paired-skill-verification]].

## Active idea

[[reduce-held-out-regressions-with-cross-validated-gating]] proposes a more
uncertainty-aware deployment gate because construction-time acceptance does not
guarantee zero regressions on a final held-out set.

## Planned evidence

[[cross-validated-verification-gate-main]] will compare the original and proposed
gates using identical candidate skills and paired held-out instances.

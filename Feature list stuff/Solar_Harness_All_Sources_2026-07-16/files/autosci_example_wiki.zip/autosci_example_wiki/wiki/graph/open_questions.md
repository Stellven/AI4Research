# Open Questions

## Agent skill synthesis

- How can construction-time verification better predict held-out regressions?
- How should verification data be sampled under distribution shift?
- When should a skill be deprecated rather than refined?
- How can multiple skills be composed without harmful interference?
- Which parts of a generated skill transfer reliably across base models?

## Current highest-priority test

Evaluate [[reduce-held-out-regressions-with-cross-validated-gating]] through
[[cross-validated-verification-gate-main]].

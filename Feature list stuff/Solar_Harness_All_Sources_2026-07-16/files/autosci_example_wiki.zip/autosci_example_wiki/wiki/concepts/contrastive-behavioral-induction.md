---
title: "Contrastive behavioral induction"
aliases: [contrastive trajectory induction]
tags: [trajectory-analysis, failures, successes, clustering]
maturity: emerging
definition: "A process that derives reusable guidance by comparing failed trajectories with successful trajectories, including nearby same-task contrasts."
key_papers: ["[[skillgen-verified-inference-time-agent-skill-synthesis]]"]
first_introduced: "SKILLGEN (2026)"
date_updated: 2026-06-19
related_concepts: ["[[inference-time-agent-skills]]", "[[paired-skill-verification]]"]
linked_ideas: []
parent_topic: agent-skill-synthesis
---

## Definition

Compress successful and failed trajectories into task abstractions, recurring
failure patterns, reusable success procedures, and local contrasts.

## Intuition

Failures reveal where help is needed, while successes reveal what the same agent can
already do. Comparing them can expose a missing intermediate check or omitted
procedure that neither success-only nor failure-only summarization isolates.

## Variants

- Cluster-level failure/success comparison
- Nearest-neighbor failure-success pairing
- Rule induction from outcome-labeled traces

## Comparison

Ordinary trajectory summarization describes what happened. Contrastive induction
tries to identify the behavior that separates a nearby success from a failure.

## Known limitations

The quality depends on trajectory labels, embedding quality, clustering, and whether
a meaningful successful neighbor exists.

## Open problems

Robust pairing under heterogeneous tasks and preserving causal rather than merely
correlational contrasts.

## Relationship to foundations

It is a form of empirical behavioral comparison rather than a guarantee of causal
identification.

## Realized by

- [[skillgen]]

## My understanding

This is the knowledge-extraction stage that turns long traces into a compact object
usable by downstream skill generation.

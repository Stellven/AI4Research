---
title: "Inference-time agent skills"
aliases: [agent skills, runtime skills]
tags: [agents, prompting, tools, reusable-procedures]
maturity: active
definition: "Auditable bundles of instructions, scripts, and resources loaded at inference time to alter an agent's behavior without updating model weights."
key_papers: ["[[skillgen-verified-inference-time-agent-skill-synthesis]]"]
first_introduced: "Prior agent-skill literature; operationalized as an intervention in SKILLGEN"
date_updated: 2026-06-19
related_concepts: ["[[paired-skill-verification]]", "[[contrastive-behavioral-induction]]"]
linked_ideas: []
parent_topic: agent-skill-synthesis
---

## Definition

A reusable inference-time artifact that modifies how an agent reasons, acts, or uses
tools without retraining the underlying model.

## Intuition

A skill is closer to a versioned operating procedure than to hidden model knowledge:
it can be inspected, edited, enabled, disabled, and evaluated independently.

## Variants

- Natural-language instruction skill
- Instruction plus executable helper scripts
- Instruction plus reference resources
- Dynamically retrieved skill libraries

## Comparison

Unlike fine-tuning, skills do not update parameters. Unlike one-off prompting, they
are intended to be reusable, named, and auditable.

## Known limitations

A generally useful skill can overgeneralize and disturb behavior that was already
correct.

## Open problems

Reliable routing, held-out regression prediction, compositional interference, and
safe lifecycle management.

## Relationship to foundations

Interpreting a skill as an intervention connects skill evaluation to
[[potential-outcomes]].

## Realized by

- [[skillgen]]

## My understanding

The main engineering value is explicit control over acquired procedural knowledge.

---
title: "Paired skill verification"
aliases: [paired intervention evaluation, repair-regression evaluation]
tags: [evaluation, interventions, regressions, agent-skills]
maturity: emerging
definition: "Evaluation of the same task instances with and without a candidate skill, tracking repairs, regressions, and net gain."
key_papers: ["[[skillgen-verified-inference-time-agent-skill-synthesis]]"]
first_introduced: "Formalized for skill synthesis in SKILLGEN (2026)"
date_updated: 2026-06-19
related_concepts: ["[[inference-time-agent-skills]]", "[[contrastive-behavioral-induction]]"]
linked_ideas: ["[[reduce-held-out-regressions-with-cross-validated-gating]]"]
parent_topic: agent-skill-synthesis
---

## Definition

Run the same base agent on the same instances under two conditions: no skill and
candidate skill. Classify changed outcomes as repairs or regressions and select using
their net effect.

## Intuition

Average accuracy alone can hide the fact that a skill repairs some failures while
breaking previously correct cases.

## Variants

- Fixed verification subset
- Guard checks on baseline successes
- Cross-validated or uncertainty-aware gating

## Comparison

Unpaired before/after averages do not identify instance-level repairs and regressions.

## Known limitations

A candidate can pass one verification subset and still regress under distribution
shift or on a final held-out set.

## Open problems

Calibrated acceptance thresholds, verification-set selection, and confidence bounds
for small samples.

## Relationship to foundations

The framing draws on [[potential-outcomes]] by treating the skill as an intervention.

## Realized by

- [[skillgen]]

## My understanding

This is both an evaluation protocol and a deployment safety gate.

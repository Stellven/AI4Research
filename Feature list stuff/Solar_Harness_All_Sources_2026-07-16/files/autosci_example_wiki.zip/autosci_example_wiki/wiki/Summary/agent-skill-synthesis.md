---
title: "Agent Skill Synthesis"
scope: "Automatic construction and verification of reusable inference-time procedures for LLM agents"
key_topics: ["[[agent-skill-synthesis]]"]
paper_count: 1
date_updated: 2026-06-19
---

## Overview

Agent skill synthesis aims to convert experience into inspectable procedures that can
be loaded at inference time.

## Core areas

- Trajectory collection
- Failure and success analysis
- Skill generation
- Skill verification
- Refinement and selection
- Deployment and lifecycle control

## Evolution

The field is moving from manually authored instructions and success-only extraction
toward explicit failure analysis, multi-agent construction, and empirical deployment
gates.

## Current frontiers

Regression-aware verification, transferable skills, multi-skill composition,
resource-bundle skills, and continual memory across projects.

## Key references

- [[skillgen-verified-inference-time-agent-skill-synthesis]]

## Related

- [[agent-skill-synthesis]]
- [[skillgen]]

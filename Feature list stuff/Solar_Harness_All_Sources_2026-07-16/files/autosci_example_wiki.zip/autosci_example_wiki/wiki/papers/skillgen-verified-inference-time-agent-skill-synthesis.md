---
title: "SKILLGEN: Verified Inference-Time Agent Skill Synthesis"
slug: skillgen-verified-inference-time-agent-skill-synthesis
arxiv: "2605.10999"
venue: "arXiv preprint"
year: 2026
tags: [agent-skills, skill-synthesis, multi-agent, verification, inference-time]
importance: 4
date_added: 2026-06-19
source_type: pdf
s2_id: ""
tldr: "SKILLGEN learns an auditable inference-time agent skill from successful and failed trajectories, then selects it through paired verification of repairs and regressions."
contribution_type: [method, system, evaluation]
datasets: [ALFWorld, LiveCodeBench, MCPBench, Mind2Web, PubMedQA, ScienceWorld, SocialMaze, ChemLLMBench]
code_url: "https://github.com/yccm/SkillGen"
cited_by: []
---

## Problem & Context

Agent skills can encode reusable instructions, scripts, and reference material without
changing model weights, but high-quality skills are still largely written manually.
Previous automatic approaches often learn mainly from successful trajectories and do
not explicitly measure whether a generated skill introduces regressions on cases that
the base agent already solved.

## Key idea

Treat a skill as an inference-time **intervention**. Learn from both successful and
failed baseline trajectories, generate candidate skills, and compare the base agent
with and without each candidate on identical verification instances.

The diagnostic summary is:

`Z = (a0, F, S, C)`

where `a0` is a task abstraction, `F` contains clustered failure patterns, `S`
contains reusable success techniques, and `C` contains local failure-success
contrasts.

A candidate skill is:

`s = (u, a, P, R)`

where `u` is structured guidance, `a` is metadata, `P` is an optional script bundle,
and `R` is optional reference material.

## Method

1. **Baseline elicitation** — collect successful and failed base-agent trajectories
   and cache no-skill outcomes on the verification subset.
2. **Contrastive behavioral induction** — compress trajectories into task context,
   failure clusters, success clusters, and nearby failure-success contrasts.
3. **Generation–verification–refinement** — generate a skill, evaluate it on the
   verification set, produce keep/remove/add/emphasize feedback, and refine it.

For each verification instance:

- repair: baseline fails, skill succeeds;
- regression: baseline succeeds, skill fails;
- net gain: `repairs - regressions`.

The system selects the best verified candidate across refinement rounds rather than
blindly taking the final candidate. A verification gate marks the selected skill
`active` only when its net gain clears the configured threshold.

## Experiment & Results

The paper evaluates the method across interactive, scientific, coding, web, and
tool-use benchmarks with open-weight and proprietary models. Reported average
held-out gains across the eight evaluated base agents range from **+3.27 to +10.08
percentage points**. Across 80 benchmark/model entries, 50 improve, 25 are unchanged,
and 5 regress.

Ablations indicate that contrastive induction, refinement, the verification gate,
failure lessons, and script/reference bundles each contribute in the settings where
they are applicable.

## Limitations

- A skill accepted during construction can still regress on a different held-out set.
- Interactive failures often involve incomplete execution of a full procedure.
- Chemistry failures can arise from incorrect grounding of reaction roles.
- Coding skills cannot always recover missing global algorithmic structure.
- Benefits depend on the task being procedurally learnable rather than purely
  knowledge-bound.

## Open questions

- Can uncertainty-aware or cross-validated gates better predict held-out regressions?
- How should the verification subset be selected under distribution shift?
- How should multiple verified skills be routed without conflating synthesis quality
  with retrieval quality?
- Can evidence about failures compound safely across projects and model families?

## My take

The strongest contribution is not merely automatic prompt writing. It is the use of
paired intervention testing to make both repairs and regressions visible before
deployment. The remaining weakness is that construction-time verification can still
overfit its verification subset.

## Related

- Topic: [[agent-skill-synthesis]]
- Concepts: [[inference-time-agent-skills]], [[contrastive-behavioral-induction]],
  [[paired-skill-verification]]
- Method: [[skillgen]]
- Foundation: [[potential-outcomes]]

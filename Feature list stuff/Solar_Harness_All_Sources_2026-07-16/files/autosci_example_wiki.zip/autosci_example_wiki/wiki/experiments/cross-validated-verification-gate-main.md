---
title: "Main paired evaluation of cross-validated skill gating"
slug: cross-validated-verification-gate-main
status: planned
linked_idea: reduce-held-out-regressions-with-cross-validated-gating
evaluates_methods: ["[[skillgen]]"]
hypothesis: "Cross-validated uncertainty-aware gating reduces held-out regressions relative to the original SKILLGEN gate without eliminating most repairs."
tags: [main, paired-evaluation, verification-gate]
setup:
  model: "Same base-agent models for baseline and treatment"
  dataset: "Controlled task instances split into induction, construction verification, and final held-out test sets"
  hardware: "API-based inference; local orchestration"
  framework: "Python paired-rollout harness"
metrics: [baseline_accuracy, skill_accuracy, repairs, regressions, net_gain, gate_acceptance_rate, token_cost]
baseline: "Original SKILLGEN best-of-K candidate selection with fixed verification gate"
outcome:
key_result: ""
date_planned: 2026-06-19
date_completed:
run_log: ""
started: ""
estimated_hours: 4
remote:
  server: ""
  gpu: ""
  session: ""
  started: ""
  completed: ""
---

## Objective

Determine whether a cross-validated deployment gate better predicts a skill's final
held-out effect than the original fixed verification gate.

## Setup

Use identical candidate skills, base models, instance identifiers, seeds, and
evaluators across both gating policies. Keep the final held-out pool disjoint from all
construction-time decisions.

## Procedure

1. Generate or load the same candidate-skill sequence for each run.
2. Apply the original fixed gate.
3. Apply the proposed cross-validated uncertainty-aware gate.
4. Evaluate the selected intervention from each condition on identical held-out
   instances.
5. Count repairs and regressions instance by instance.
6. Report net gain, confidence intervals, cost, and acceptance rate.

Success criterion: fewer held-out regressions than the original gate while retaining
at least 80% of its repairs and maintaining positive mean net gain.

## Results

Not run.

## Analysis

Pending.

## Idea updates

No verdict yet.

## Follow-up

If the gate is too conservative, test adaptive fold count or a Pareto rule over net
gain and regression risk.

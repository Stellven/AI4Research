# Generated Outputs

This directory is where AutoSci may place artifacts such as survey sections,
`PAPER_PLAN.md`, pipeline reports, and manuscript-related intermediate outputs.

---
title: "Potential outcomes"
slug: potential-outcomes
domain: "causal inference"
status: mainstream
aliases: [Rubin causal model]
first_introduced: "Classical causal inference literature"
date_updated: 2026-06-19
source_url: ""
---

## Definition

A framework that describes the outcome an experimental unit would exhibit under each
possible intervention, even though only one outcome is observed in a given run.

## Relevance to this wiki

SKILLGEN uses the framework conceptually to compare a base agent's outcome on the same
instance with and without a skill intervention.

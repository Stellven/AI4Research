---
name: "SKILLGEN"
slug: skillgen
type: system
tags: [agent-skills, contrastive-induction, verification, multi-agent]
source_papers: ["[[skillgen-verified-inference-time-agent-skill-synthesis]]"]
parent_methods: []
child_methods: []
realizes_concepts: ["[[inference-time-agent-skills]]", "[[contrastive-behavioral-induction]]", "[[paired-skill-verification]]"]
code_repo: "https://github.com/yccm/SkillGen"
date_updated: 2026-06-19
---

## Problem setting

Given a base agent, outcome-labeled trajectories, an induction subset, a verification
subset, and an evaluator, synthesize one reusable skill that improves the base agent.

## Mechanism

SKILLGEN contrasts failures and successes, converts the resulting diagnostic summary
into candidate skills, and evaluates each candidate as an intervention.

## Procedure

1. Collect baseline induction trajectories and verification baselines.
2. Build `Z = (a0, F, S, C)`.
3. Generate `s^(1)`.
4. Evaluate repairs, regressions, unresolved failures, and net gain.
5. Produce structured refinement feedback.
6. Repeat for a fixed round budget.
7. Select the best verified candidate and activate it only if it passes the gate.

## Assumptions

- A task-level evaluator can score trajectories.
- The base agent exhibits both useful successes and informative failures.
- Verification instances are representative enough to predict deployment behavior.
- The skill interface can inject instructions and optional resources consistently.

## Limitations

Construction-time verification can overfit; learned procedures may not transfer to
knowledge-bound or globally mis-specified tasks.

## Tradeoff profile

More verification and refinement can improve reliability but increase token cost and
latency. Best-of-K selection is safer than using the latest refinement round.

## Evaluated by

- ALFWorld
- LiveCodeBench
- MCPBench
- Mind2Web
- PubMedQA
- ScienceWorld
- SocialMaze
- ChemLLMBench

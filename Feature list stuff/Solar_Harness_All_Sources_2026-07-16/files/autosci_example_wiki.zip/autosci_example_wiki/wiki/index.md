# Wiki Index

papers:
  - skillgen-verified-inference-time-agent-skill-synthesis

concepts:
  - inference-time-agent-skills
  - contrastive-behavioral-induction
  - paired-skill-verification

topics:
  - agent-skill-synthesis

people:

ideas:
  - reduce-held-out-regressions-with-cross-validated-gating

methods:
  - skillgen

experiments:
  - cross-validated-verification-gate-main

Summary:
  - agent-skill-synthesis

foundations:
  - potential-outcomes

---
title: "Agent skill synthesis"
tags: [agents, skills, inference-time-learning, verification]
key_venues: [ICLR, NeurIPS, ACL]
related_topics: []
key_people: []
key_papers: ["[[skillgen-verified-inference-time-agent-skill-synthesis]]"]
linked_ideas: ["[[reduce-held-out-regressions-with-cross-validated-gating]]"]
---

## Overview

Methods that acquire reusable agent procedures from trajectories, demonstrations,
failures, interaction history, or synthetic experience without necessarily updating
model weights.

## Timeline

- Early agent systems established reusable tool-use and reflection patterns.
- Later systems constructed skill libraries from agent experience.
- SKILLGEN emphasizes contrastive failure analysis and paired verification.

## Seminal works

- [[skillgen-verified-inference-time-agent-skill-synthesis]]

## SOTA tracker

Current systems differ in whether they produce one fixed skill or a routed library,
whether they include scripts/resources, and whether deployment is gated by empirical
paired evaluation.

## Key benchmarks

ALFWorld, ScienceWorld, Mind2Web, LiveCodeBench, MCPBench, SocialMaze, PubMedQA,
and ChemLLMBench.

## Open problems

### Known gaps

- Verification subsets do not perfectly predict final held-out regressions.
- Skills can interfere when composed.
- Transfer varies substantially across source and evaluator models.

### Methodological gaps

- Confidence-aware deployment rules
- Distribution-shift-aware verification
- Fair evaluation of single-skill versus skill-library systems

## Concepts

- [[inference-time-agent-skills]]
- [[contrastive-behavioral-induction]]
- [[paired-skill-verification]]
